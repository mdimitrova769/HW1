package edu.iit.cs445.spring22;

public class Ant extends Creature {

	public Ant() {
		// TODO Auto-generated constructor stub
		super();
	}

	public Ant(String name1) {
		super(name1);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void move() {
		// TODO Auto-generated method stub
		System.out.println(this.getName() + " " + this.getClass().getSimpleName()+" is crawling around.");

	}
	
}
