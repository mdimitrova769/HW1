package edu.iit.cs445.spring22;


public class Bat extends Creature implements Flyer {
	private Thing food = new Thing("null");
	public Bat() {
		// TODO Auto-generated constructor stub
		super();
	}

	public Bat(String name1) {
		super(name1);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void move() {
		// TODO Auto-generated method stub
		this.fly();

	}
	
	public void fly() {
		System.out.println(this.getName() + " " + this.getClass().getSimpleName()+" is swooping through the dark.");
	}
	
	@Override
	public void eat(Thing aThing) {
		if ((aThing.getClass().getSimpleName().equalsIgnoreCase("Thing"))) {
			System.out.println(this.getName()+ " "+this.getClass().getSimpleName() + " "+ " won't eat a "+aThing.toString());
			
		} else {
			if ((aThing.getClass().getSimpleName().equalsIgnoreCase("Creature"))) {
				System.out.println(	this.getName()  + " " +  this.getClass().getSimpleName() + " has eaten a "+ aThing.getName());
				food.setName(aThing.getName());
			}
			else
			{
				System.out.println("");
			}
		}
		
	}
	
	@Override
	public void whatDidYouEat() {
		if (food.getName().equalsIgnoreCase("null")) {
			System.out.println(	this.getName() + " " + this.getClass().getSimpleName() + " has had nothing to eat! ");
		}
		else {
			System.out.println(	this.getName()  + " " +  this.getClass().getSimpleName() + " has eaten a "+ food.getName());
		}

	}

}
