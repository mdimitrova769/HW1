package edu.iit.cs445.spring22;

public class Tiger extends Creature {
	
	public Tiger() {
		// TODO Auto-generated constructor stub
		super();
	}

	public Tiger(String name1) {
		super(name1);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void move() {
		// TODO Auto-generated method stub
		System.out.println(this.getName()+this.getClass().getSimpleName()+" has just pounced.");
	}

}
