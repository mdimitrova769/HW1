package edu.iit.cs445.spring22;


public interface Flyer {
	
	public void fly();

}
