package edu.iit.cs445.spring22;

public class Ant extends Creature {
	
	String move;

	public Ant() {
		// TODO Auto-generated constructor stub
		super();
	}

	public Ant(String name1) {
		super(name1);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void move() {
		// TODO Auto-generated method stub
		move = this.getName() + " " + this.getClass().getSimpleName()+" is crawling around.";
System.out.println(move);
	}
	
	public String print_move_ant () {
		return move;
	}
	
}
