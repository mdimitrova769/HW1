package edu.iit.cs445.spring22;

public abstract class Creature extends Thing {
	
	private String name;
	String food2;
	private Thing food = new Thing("null");

	public Creature() {
		super()	;
		this.name = "null";
	}

	public Creature(String name1) {
		super(name1);
		this.name = name1;
	}

	public String getName() {
		return name;
	}

	public void setName(String name1) {
		this.name = name1;
	}
	
	public void eat (Thing aThing) {
		food2 = this.toString() + " has just eaten " + aThing.toString();
		food.setName(aThing.getName());
		System.out.println(food2);

	}

	public abstract void move();
	
	public void whatDidYouEat() {
		if (food.getName().equalsIgnoreCase("null")) {
			System.out.println(	this.getName() + " " + this.getClass().getSimpleName() + " has had nothing to eat! ");
		}
		else {
			System.out.println(	this.getName()  + " " +  this.getClass().getSimpleName() + " has eaten a "+ food.getName());
		}

	}
	
}
