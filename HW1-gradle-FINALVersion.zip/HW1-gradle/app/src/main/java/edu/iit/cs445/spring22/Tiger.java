package edu.iit.cs445.spring22;

public class Tiger extends Creature {
	
	String move;
	
	public Tiger() {
		// TODO Auto-generated constructor stub
		super();
	}

	public Tiger(String name1) {
		super(name1);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void move() {
		// TODO Auto-generated method stub
		move = this.getName()+" "+this.getClass().getSimpleName()+" has just pounced.";
		System.out.println(move);

	
	}
	
	public String print_move_tiger() {
		return move;
	}

}
