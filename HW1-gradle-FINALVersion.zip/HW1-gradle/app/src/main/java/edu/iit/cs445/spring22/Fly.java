package edu.iit.cs445.spring22;


public class Fly extends Creature implements Flyer {
	Boolean moved = false;
	String food2;
	String food3;
	private Thing food = new Thing("null");
	public Fly() {
		// TODO Auto-generated constructor stub
		super();
	}

	public Fly(String name1) {
		super(name1);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void move() {
		moved = true;
		// TODO Auto-generated method stub
		this.fly();
	}
	
	public Boolean did_fly_flied() {
		return moved;
	}

	@Override
	public void fly() {
		// TODO Auto-generated method stub
		System.out.println(this.getName()+" "+this.getClass().getSimpleName()+" "+" is buzzing around in flight.");
	}
	
	@Override
	public void eat(Thing aThing) {
		if ((aThing.getClass().getSimpleName().equalsIgnoreCase("thing"))) {
			
			System.out.println(this.getName()+ " "+this.getClass().getSimpleName() + " "+ " has just eaten a "+aThing.toString());

			food2 = this.getName()+ " "+this.getClass().getSimpleName() + " "+ " has just eaten a "+aThing.toString();
			food.setName(aThing.getName());
		} else {
			if ((aThing.getClass().getSimpleName().equalsIgnoreCase("creature"))) {
				System.out.println(this.getName()  + " " +  this.getClass().getSimpleName() + " won't eat a "+ aThing.getName());

				food2 =	this.getName()  + " " +  this.getClass().getSimpleName() + " won't eat a "+ aThing.getName();
			}
			else
			{
				System.out.println("");
				food2="";
			}
		}
	}
	
	public String what_did_eat() {
		return food2;
	}
		
		@Override
		public void whatDidYouEat() {
			if (food.getName().equalsIgnoreCase("null")) {
				
				food3 =	this.getName() + " " + this.getClass().getSimpleName() + " has had nothing to eat! ";
				System.out.println(food3);
			
			}
			else {
				food3 = this.getName() + " " +  this.getClass().getSimpleName() + " has eaten a "+ food.getName();
			
				System.out.println(food3);
			}

		}
		
		public String what_did_did_eat() {
			return food3;
		}
	

}
