package edu.iit.cs445.spring22;

public class Thing {
	
	private String name;
	
	public Thing() {
		this.name = "null";
	}

	public Thing(String name1) {
		this.name = name1;
	}

	public String getName() {
		return name;
	}

	public void setName(String name1) {
		this.name = name1;
	}

	@Override 
	public String toString() {
		if (this.getClass().getSimpleName().equalsIgnoreCase("thing")) {
			return this.getName();
		} else {
			return this.getName()+", "+this.getClass().getSimpleName().toString();
		}
	}

}
